from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
import httpx
import traceback

AUTH_SERVICE_ME_URL = "http://localhost:8001/api/v1/users/auth/me"


class AuthorizationMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):

        # Only process HTTP requests
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request = Request(scope, receive=receive)

        public_paths = [
            "/",
            "/api/v1/users/login",
            "/api/v1/users/register",
            "/api/v1/users/refresh",
            "/docs",
            "/openapi.json"
        ]

        # Skip public routes
        if request.method == "OPTIONS" or request.url.path in public_paths:
            await self.app(scope, receive, send)
            return

        # ---------------------------
        # 1️⃣ AUTH VALIDATION BLOCK
        # ---------------------------
        try:
            access_token = request.cookies.get("access_token")

            if not access_token:
                raise HTTPException(status_code=401, detail="Access token missing")

            print("🔐 Validating token with auth service...")

            async with httpx.AsyncClient(timeout=5) as client:
                response = await client.get(
                    AUTH_SERVICE_ME_URL,
                    headers={"Authorization": f"Bearer {access_token}"}
                )

            print("🔐 Auth service response status:", response.status_code)

            if response.status_code != 200:
                raise HTTPException(status_code=401, detail="Invalid or expired token")

            scope["user"] = response.json()

        except HTTPException as e:
            print("❌ AUTH VALIDATION ERROR:", e.detail)
            res = JSONResponse(
                status_code=e.status_code,
                content={"detail": e.detail}
            )
            await res(scope, receive, send)
            return

        except Exception as e:
            print("🔥 AUTH SERVICE EXCEPTION:")
            traceback.print_exc()

            res = JSONResponse(
                status_code=500,
                content={"detail": f"Auth middleware error: {str(e)}"}
            )
            await res(scope, receive, send)
            return

        # ---------------------------
        # 2️⃣ DOWNSTREAM APP BLOCK
        # ---------------------------
        try:
            print("➡ Passing request to downstream app...")
            await self.app(scope, receive, send)
            print("⬅ Downstream app completed successfully")

        except Exception as e:
            print("🔥 DOWNSTREAM APPLICATION ERROR:")
            traceback.print_exc()
            raise