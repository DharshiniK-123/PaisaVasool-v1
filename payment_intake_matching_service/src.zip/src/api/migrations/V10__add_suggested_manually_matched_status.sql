-- V10__add_suggested_manually_matched_status.sql
--
-- Adds index for SUGGESTED status to support fast pending-review queries.
-- No column changes needed — match_status is VARCHAR(50) and already accepts any string.
-- This migration just documents the new allowed values and adds the index.

-- Index for pending review dashboard (filters by SUGGESTED frequently)
CREATE INDEX IF NOT EXISTS idx_matching_suggested
    ON matching_payment_invoice (payment_detail_id)
    WHERE match_status = 'SUGGESTED';

-- Index for manually matched lookups
CREATE INDEX IF NOT EXISTS idx_matching_manually_matched
    ON matching_payment_invoice (payment_detail_id)
    WHERE match_status = 'MANUALLY_MATCHED';

-- Optional: add a comment documenting all valid statuses
COMMENT ON COLUMN matching_payment_invoice.match_status IS
    'FULL          — payment fully covers invoice
     PARTIAL       — payment partially covers invoice
     OVERPAYMENT   — payment exceeds invoice amount
     FAILED        — could not match, manual review required
     DUPLICATE     — payment already matched to this invoice
     SUGGESTED     — deep match candidate, pending human approval
     MANUALLY_MATCHED — human explicitly assigned payment to invoice';
