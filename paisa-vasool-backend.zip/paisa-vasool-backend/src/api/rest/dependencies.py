from src.data.clients.postgres_client import AsyncSessionLocal


async def get_db():
    async with AsyncSessionLocal() as Session:
        yield Session

from fastapi import Depends, HTTPException, Request
from src.config.jwthandler import verify_access_token

async def get_current_user(request: Request):
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        raise HTTPException(status_code=401, detail="Missing Authorization header")

    scheme, token = auth_header.split(" ")
    if scheme != "Bearer":
        raise HTTPException(status_code=401, detail="Invalid auth scheme")

    payload = verify_access_token(token)
    if payload is None:
        raise HTTPException(status_code=401, detail="Invalid or expired token")

    return payload