export type MatchStatus = 'FULL' | 'PARTIAL' | 'OVERPAYMENT' | 'DUPLICATE' | 'FAILED';

export interface MatchRecord {
  id: number;
  payment_detail_id: number;
  invoice_id: number;
  match_status: MatchStatus;
  matched_amount?: number | null;
  discrepancy_amount?: number | null;
  match_notes?: string | null;
  created_at: string;
  [key: string]: unknown;
}

export interface MatchPaymentDetail {
  id: number;
  amount?: number | null;
  payer_name?: string | null;
  payment_date?: string | null;
  reference_number?: string | null;
  bank_name?: string | null;
  [key: string]: unknown;
}

export interface MatchInvoiceData {
  id: number;
  invoice_number?: string | null;
  customer_name?: string | null;
  total_amount?: number | null;
  due_date?: string | null;
  payment_status?: string | null;
  [key: string]: unknown;
}

export interface MatchingState {
  matches: MatchRecord[];
  unmatchedPayments: MatchPaymentDetail[];
  unmatchedInvoices: MatchInvoiceData[];
  loading: boolean;
  refreshing: boolean;
  unmatchedPaymentsLoading: boolean;
  unmatchedInvoicesLoading: boolean;
  error: string | null;
}
