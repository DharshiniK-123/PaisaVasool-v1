from src.data.clients.postgres_client import AsyncSessionLocal


async def get_db():
    async with AsyncSessionLocal() as Session:
        yield Session

from fastapi import Depends, HTTPException, Request
from src.config.jwthandler import verify_access_token

async def get_current_user(request: Request):
    print("get current user entered-------------------------")
    auth_header = request.headers.get("Authorization")
    
    if auth_header:
        print("auth header found................")
        try:
            scheme, token = auth_header.split(" ")
        except ValueError:
            raise HTTPException(status_code=401, detail="Invalid authorization format")
        if scheme != "Bearer":
            raise HTTPException(status_code=401, detail="Invalid auth scheme")
    else:
        print("auth header not found-----------------")
        token = request.cookies.get("access_token")
        print("token found-----------------")
        if not token:
            raise HTTPException(status_code=401, detail="Missing Authorization header or cookie")
    print("before verify---------")
    payload = verify_access_token(token)
    print("after verify---------")
    if payload is None:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    print(payload,"----------------------")
    return payload